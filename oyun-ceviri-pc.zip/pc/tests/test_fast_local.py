import unittest

from fast_local import FastGameTranslator
from session import DEFAULTS, build_manager, make_fast
from subtitle_core import TranslationError, TranslatorManager


class FastLocalTests(unittest.TestCase):
    def setUp(self):
        self.t = FastGameTranslator()

    def check(self, expected, english):
        self.assertEqual(expected, self.t.translate_or_none(english), english)

    def test_fixed_phrases(self):
        self.check("Bekle biraz!", "Hold on!")
        self.check("İyi misin?", "Are you okay?")
        self.check("Gel buraya!", "Get over here!")
        self.check("Hadi gidelim.", "Let's go.")

    def test_object_pronouns_do_not_change_subject(self):
        self.check("Seni seviyorum.", "I love you.")
        self.check("Seni öldüreceğim.", "I will kill you.")
        self.check("Senden nefret ediyorum.", "I hate you.")
        self.check("Onu gördüm.", "I saw him.")

    def test_case_suffixes(self):
        self.check("Kapıyı aç.", "Open the door.")
        self.check("Anahtarı al.", "Take the key.")
        self.check("Kapıya bak.", "Look at the door.")
        self.check("Odaya git.", "Go to the room.")
        self.check("Kardeşimi öldürdü.", "He killed my brother.")
        self.check("Anahtarlarımı kaybettim.", "I lost my keys.")
        self.check("Bunu al.", "Take this.")
        self.check("Bunun için ödeyeceksin.", "You will pay for this.")

    def test_indirect_object(self):
        self.check("Bana silahı ver.", "Give me the gun.")
        self.check("Hepsini öldür!", "Kill them all!")

    def test_questions(self):
        self.check("Anahtar nerede?", "Where is the key?")
        self.check("Kardeşim nerede?", "Where is my brother?")
        self.check("Benden ne istiyorsun?", "What do you want from me?")
        self.check("Hazır mısın?", "Are you ready?")
        self.check("Bana güveniyor musun?", "Do you trust me?")
        self.check("Nereye gidiyorsun?", "Where are you going?")

    def test_nominal_sentences(self):
        self.check("Hazır değilsin.", "You are not ready.")
        self.check("Korkmuş değilim.", "I am not afraid.")
        self.check("Kapı kilitli.", "The door is locked.")
        self.check("Adam burada.", "The man is here.")

    def test_negative_imperative(self):
        self.check("Ateş etme!", "Don't shoot!")
        self.check("Oraya gitme.", "Don't go there.")
        self.check("Hareket etme!", "Don't move!")

    def test_tenses(self):
        self.check("Koşuyordu.", "She was running.")
        self.check("Gidemem.", "I can not go.")
        self.check("Kaçamazsın.", "You can not escape.")
        self.check("Anahtarı bulmalıyız.", "We must find the key.")
        self.check("Pes ediyorum.", "I give up.")
        self.check("Şimdi gitmemiz gerekiyor.", "We need to go now.")

    def test_speaker_is_kept(self):
        self.check("Leon: Dikkat et arkanda!", "Leon: Watch out, behind you!")

    def test_unknown_words_return_none(self):
        self.assertIsNone(self.t.translate_or_none("I think we should leave this place before they find us."))
        self.assertIsNone(self.t.translate_or_none("It's the end of the world."))
        self.assertIsNone(self.t.translate_or_none("I need your help."))
        self.assertIsNone(self.t.translate_or_none("Meeting at 10:30"))
        self.assertIsNone(self.t.translate_or_none("forget upgrade"))

    def test_ocr_noise(self):
        self.check("Anahtarı bulacağım.", "♪ I will find the key. ♪")

    def test_empty(self):
        self.assertIsNone(self.t.translate_or_none(""))
        self.assertIsNone(self.t.translate_or_none("   "))

    def test_cache_is_stable(self):
        self.assertEqual(self.t.translate_or_none("Open the door."), self.t.translate_or_none("Open the door."))


class _Boom:
    calls = 0

    def translate(self, text):
        _Boom.calls += 1
        return "GEMINI " + text

    def close(self):
        pass


class ManagerFastPathTests(unittest.TestCase):
    def mgr(self, fast):
        m = TranslatorManager(_Boom(), None, clock=lambda: 0.0)
        m.fast = fast
        _Boom.calls = 0
        return m

    def test_fast_hit_skips_primary(self):
        m = self.mgr(lambda t: "bekle")
        self.assertEqual("bekle", m.translate("hold on"))
        self.assertEqual(0, _Boom.calls)

    def test_fast_none_falls_through(self):
        m = self.mgr(lambda t: None)
        self.assertEqual("GEMINI x", m.translate("x"))

    def test_broken_fast_never_blocks(self):
        notes = []
        m = TranslatorManager(_Boom(), None, clock=lambda: 0.0, on_notice=notes.append)

        def bad(_t):
            raise RuntimeError("bug")

        m.fast = bad
        self.assertEqual("GEMINI x", m.translate("x"))
        self.assertTrue(any("bug" in n for n in notes))


class SessionFastTests(unittest.TestCase):
    def s(self, **kw):
        return dict(DEFAULTS, **{"mode": "offline", "gemini_key": "K", **kw})

    def test_gemini_online_skips_fast(self):
        self.assertIsNone(make_fast(self.s(mode="online")))

    def test_disabled_gives_none(self):
        self.assertIsNone(make_fast(self.s(fast_local=False)))

    def test_enabled_translates_known_line(self):
        self.assertEqual("Kapıyı aç.", make_fast(self.s())("Open the door."))

    def test_glossary_term_leaves_the_line_to_gemini(self):
        f = make_fast(self.s(glossary="Scorpion=Akrep"))
        self.assertIsNone(f("Open the door, Scorpion."))
        self.assertEqual("Kapıyı aç.", f("Open the door."))

    def test_build_manager_installs_fast(self):
        m = build_manager(self.s(), lambda _m: None)
        self.assertEqual("Bekle biraz!", m.translate("Hold on!"))


if __name__ == "__main__":
    unittest.main()


class OllamaHyMtTests(unittest.TestCase):
    def test_hymt_models_get_the_plain_translation_prompt(self):
        from translators import OllamaTranslator
        t = OllamaTranslator("hf.co/tencent/HY-MT1.5-1.8B-GGUF:Q4_K_M", "Mortal Kombat 11", "hint")
        self.assertTrue(t.is_hymt)
        req = t.build_request("Get over here!")
        self.assertTrue(req["prompt"].startswith("Translate the following segment into Turkish"))
        self.assertTrue(req["prompt"].endswith("Get over here!"))
        self.assertNotIn("Mortal Kombat", req["prompt"])
        self.assertEqual(20, req["options"]["top_k"])

    def test_other_models_keep_the_game_prompt(self):
        from translators import OllamaTranslator
        t = OllamaTranslator("gemma2:2b", "Mortal Kombat 11", "")
        self.assertFalse(t.is_hymt)
        self.assertIn("Mortal Kombat 11", t.build_request("Hi")["prompt"])
