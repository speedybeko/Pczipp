import unittest

from pipeline import CompositeSink, Pipeline
from subtitle_core import TranslationError, TranslatorManager

L1 = "You're talking nonsense, man. You raised a fine daughter."
L2 = "Thank you, both of you."


class Recorder:
    def __init__(self, boom=False):
        self.shown, self.cleared, self.boom = [], 0, boom

    def show(self, t):
        if self.boom:
            raise RuntimeError("x")
        self.shown.append(t)

    def clear(self):
        if self.boom:
            raise RuntimeError("x")
        self.cleared += 1


class Upper:
    calls = 0
    fail = False

    def translate(self, t):
        Upper.calls += 1
        if self.fail:
            raise TranslationError(0, "model yok")
        return "TR " + t

    def close(self):
        pass


class Harness:
    def __init__(self, translator=None):
        self.texts = []          # her step için OCR çıktısı
        self.now = 0
        self.pending = []        # çeviri işleri: elle çalıştırılır
        self.sink = Recorder()
        self.notices = []
        self.ocr_calls = 0
        self.frame_id = 0
        mgr = TranslatorManager(None, translator or Upper(), clock=lambda: self.now / 1000.0)
        self.p = Pipeline(
            grab=lambda: self.frame_id,
            ocr=self._ocr,
            manager=mgr,
            sink=self.sink,
            clock_ms=lambda: self.now,
            same_frame=lambda a, b: a == b and a is not None,
            on_notice=self.notices.append,
            submit=self.pending.append,
        )

    def _ocr(self, frame):
        self.ocr_calls += 1
        return self.texts[frame]

    def step(self, text, dt=250):
        self.texts.append(text)
        self.frame_id = len(self.texts) - 1
        self.now += dt
        self.p.step()

    def run_jobs(self):
        jobs, self.pending[:] = list(self.pending), []
        for j in jobs:
            j()


class PipelineTests(unittest.TestCase):
    def test_translates_and_shows_after_two_frames(self):
        h = Harness()
        h.step(L1)
        self.assertEqual(0, len(h.pending))
        h.step(L1)
        h.run_jobs()
        self.assertEqual(["TR " + L1], h.sink.shown)

    def test_clears_after_delay(self):
        h = Harness()
        for _ in range(2):
            h.step(L1)
        h.run_jobs()
        h.step("")
        h.step("")
        self.assertEqual(0, h.sink.cleared)
        h.step("")
        self.assertEqual(1, h.sink.cleared)

    def test_stale_translation_is_dropped(self):
        h = Harness()
        h.step(L1)
        h.step(L1)          # L1 çevirisi bekliyor
        h.step(L2)
        h.step(L2)          # L2 çevirisi de sıraya girdi
        h.run_jobs()        # ikisi de sırayla çalışır
        self.assertEqual(["TR " + L2], h.sink.shown)  # eski satır asla gösterilmedi

    def test_translation_dropped_if_cleared_meanwhile(self):
        h = Harness()
        h.step(L1)
        h.step(L1)
        for _ in range(3):
            h.step("")      # temizleme olayı geldi
        h.run_jobs()
        self.assertEqual([], h.sink.shown)

    def test_failed_translation_is_retried_for_same_line(self):
        t = Upper()
        t.fail = True
        h = Harness(t)
        h.step(L1)
        h.step(L1)
        h.run_jobs()
        self.assertEqual([], h.sink.shown)
        self.assertEqual(1, len(h.notices))
        t.fail = False
        h.step(L1, dt=1000)   # 2 sn dolmadı: henüz yeniden denenmez
        self.assertEqual(0, len(h.pending))
        h.step(L1, dt=1500)   # süre doldu: takipçi sıfırlandı
        h.step(L1)
        h.run_jobs()
        self.assertEqual(["TR " + L1], h.sink.shown)

    def test_unchanged_frame_skips_ocr(self):
        h = Harness()
        h.texts.append(L1)
        h.frame_id = 0
        for _ in range(4):
            h.now += 250
            h.p.step()
        self.assertEqual(1, h.ocr_calls)

    def test_composite_sink_isolates_errors(self):
        bad, good, errs = Recorder(True), Recorder(), []
        c = CompositeSink([bad, good], on_error=lambda s, e: errs.append(e))
        c.show("x")
        c.clear()
        self.assertEqual(["x"], good.shown)
        self.assertEqual(1, good.cleared)
        self.assertEqual(2, len(errs))


if __name__ == "__main__":
    unittest.main()
