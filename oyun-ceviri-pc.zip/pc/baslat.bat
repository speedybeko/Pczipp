@echo off
chcp 65001 >nul
python gui.py %*
pause
