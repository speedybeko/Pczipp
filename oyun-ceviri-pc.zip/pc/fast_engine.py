"""Hızlı yerel çeviri motoru (kural tabanlı, internetsiz, ≈0 ms).

Kotlin tarafındaki FastGameTranslator.kt dosyasının Python karşılığıdır. Tek kuralı: emin değilse
`None` döner (bilinmeyen kelime, karmaşık yapı). Böylece TV'de yarı İngilizce, yarı Türkçe bozuk
cümle çıkmaz; o satır Gemini'ye ya da Argos'a gider.
Yalnızca standart kütüphane kullanır.
"""
from __future__ import annotations

import re
import threading
from collections import OrderedDict
from typing import List, Optional, Set, Tuple

from fast_data import IRREGULAR_PAST, NOUN_ADJ, PHRASAL_VERBS, PHRASES, QUESTION_WORDS, VERBS

NONE, ACC, DAT, ABL, WITH = "NONE", "ACCUSATIVE", "DATIVE", "ABLATIVE", "WITH"
(P1S, P2S, P3S, P1P, P2P, P3P) = ("1s", "2s", "3s", "1p", "2p", "3p")
(PRESENT, PAST_CONT, PAST, FUTURE, AORIST, IMPERATIVE, CAN, MUST) = (
    "present", "past_cont", "past", "future", "aorist", "imperative", "can", "must")

VOWELS = "aeıioöuü"
BACK = "aıou"
HARD = "fstkçşhp"

_PHRASAL = [(re.compile(rf"\b{re.escape(k)}\b"), v)
            for k, v in sorted(PHRASAL_VERBS.items(), key=lambda kv: -len(kv[0]))]
_PHRASE = [(re.compile(rf"\b{re.escape(k)}\b"), "[" + v.replace(" ", "=") + "]")
           for k, v in sorted(PHRASES.items(), key=lambda kv: -len(kv[0])) if " " in k]
_SPEAKER = re.compile(r"^([A-Z][A-Za-z]{1,14}(?: [A-Z][A-Za-z]{1,14})?:)\s*(.+)$")
_SENTENCE_SPLIT = re.compile(r"(?<=[.!?])\s+")

TIME_ADVERBS = {"now", "today", "tonight", "tomorrow", "yesterday", "soon", "already", "again", "always"}
ADJ_PARTICIPLES = {"locked", "closed", "broken"}  # "is locked" = kilitli (fiil değil)
DITRANSITIVE = {"ver", "anlat", "gönder", "getir"}
CASE_EXEMPT = {"burada", "orada", "şimdi", "buraya", "oraya"}
OBJ_PRONOUNS = ("me", "you", "him", "her", "it", "us", "them")
POSSESSIVES = ("my", "your", "his", "her", "our", "their")
PREPOSITIONS = ("in", "on", "under", "for", "with", "without", "from", "to", "about", "behind")
AUX_START = ("do", "does", "did", "am", "is", "are", "was", "were", "can", "will", "have", "has")


def capitalize_turkish(text: str) -> str:
    if not text:
        return text
    first = text[0]
    up = "İ" if first == "i" else "I" if first == "ı" else first.upper()
    return up + text[1:]


def four_way(v: str) -> str:
    if v in "aı":
        return "ı"
    if v in "ei":
        return "i"
    if v in "ou":
        return "u"
    if v in "öü":
        return "ü"
    return "i"


def last_vowel(word: str, default: str = "e") -> str:
    for c in reversed(word):
        if c in VOWELS:
            return c
    return default


def soften_verb_root(root: str) -> str:
    soft = ("git", "et", "kaybet", "hisset", "affet", "seyret", "terk et", "yardım et", "takip et",
            "nefret et", "yok et", "tamir et", "kontrol et", "hareket et")
    if root in soft or root.endswith(" et"):
        return root[:-1] + "d"
    return root


def soften_noun(noun: str) -> str:
    if len(noun) < 3:
        return noun
    repl = {"p": "b", "ç": "c", "k": "ğ"}.get(noun[-1])
    return noun[:-1] + repl if repl else noun


def expand_contractions(text: str) -> str:
    text = text.replace("’", "'")
    pairs = [
        (r"\bi'm\b", "i am"), (r"\bim\b", "i am"), (r"\byou're\b", "you are"), (r"\bwe're\b", "we are"),
        (r"\bthey're\b", "they are"), (r"\bhe's\b", "he is"), (r"\bshe's\b", "she is"), (r"\bit's\b", "it is"),
        (r"\bdon't\b", "do not"), (r"\bdont\b", "do not"), (r"\bdoesn't\b", "does not"),
        (r"\bdidn't\b", "did not"), (r"\bdidnt\b", "did not"), (r"\bcan't\b", "can not"), (r"\bcant\b", "can not"),
        (r"\bwon't\b", "will not"), (r"\bisn't\b", "is not"), (r"\baren't\b", "are not"),
        (r"\bi'll\b", "i will"), (r"\byou'll\b", "you will"), (r"\bwe'll\b", "we will"),
        (r"\blet's\b", "let us"), (r"\blets\b", "let us"), (r"\bwhat's\b", "what is"),
        (r"\bwhere's\b", "where is"), (r"\bwho's\b", "who is"),
        (r"\bgonna\b", "will"), (r"\bwanna\b", "want"), (r"\bgotta\b", "must"),
    ]
    for pat, rep in pairs:
        text = re.sub(pat, rep, text)
    return text


def clean_ocr_noise(text: str) -> str:
    text = re.sub(r"[♪♫#*~_|<>\[\]]", "", text)
    text = re.sub(r"\b1\b", "I", text)
    text = re.sub(r"\bl'm\b", "I'm", text)
    text = re.sub(r"\bl\b", "I", text)
    text = re.sub(r"\.{2,}", ".", text)
    return re.sub(r"\s+", " ", text).strip()


# ---------- ek yardımcıları ----------

def object_pronoun(p: str, case: str) -> str:
    if case == WITH:
        return {"me": "benimle", "you": "seninle", "us": "bizimle", "them": "onlarla"}.get(p, "onunla")
    if case == DAT:
        return {"me": "bana", "you": "sana", "us": "bize", "them": "onlara"}.get(p, "ona")
    if case == ABL:
        return {"me": "benden", "you": "senden", "us": "bizden", "them": "onlardan"}.get(p, "ondan")
    return {"me": "beni", "you": "seni", "us": "bizi", "them": "onları"}.get(p, "onu")


def all_pronoun(p: str, case: str) -> str:
    us = p == "us"
    if case == DAT:
        return "hepimize" if us else "hepsine"
    if case == ABL:
        return "hepimizden" if us else "hepsinden"
    return "hepimizi" if us else "hepsini"


def possessive(noun: str, owner: str) -> str:
    soft = soften_noun(noun)
    v = four_way(last_vowel(soft))
    ends_vowel = soft[-1] in VOWELS
    if owner == "my":
        return soft + ("m" if ends_vowel else v + "m")
    if owner == "your":
        return soft + ("n" if ends_vowel else v + "n")
    if owner in ("his", "her"):
        return soft + (("s" + v) if ends_vowel else v)
    if owner == "our":
        return soft + (("m" + v + "z") if ends_vowel else v + "m" + v + "z")
    if owner == "their":
        return noun + ("ları" if last_vowel(noun) in BACK else "leri")
    return noun


def apply_case(word: str, case: str, possessed: bool) -> str:
    if case == NONE or word in CASE_EXEMPT:
        return word
    if case == WITH:
        return word + " ile"
    if word in ("bu", "şu"):
        return word + {ACC: "nu", DAT: "na"}.get(case, "ndan")
    soft = word if possessed else soften_noun(word)
    lv = last_vowel(soft)
    is_back = lv in BACK
    buf = "y" if soft[-1] in VOWELS else ""
    if case == ACC:
        return soft + buf + four_way(lv)
    if case == DAT:
        return soft + buf + ("a" if is_back else "e")
    if case == ABL:
        d = "t" if word[-1] in HARD else "d"
        return word + d + ("an" if is_back else "en")
    return word


def copula_suffix(word: str, person: str) -> str:
    if person not in (P1S, P2S, P1P):
        return ""
    v = four_way(last_vowel(word))
    y = "y" if word[-1] in VOWELS else ""
    if person == P1S:
        return f"{y}{v}m"
    if person == P2S:
        return f"s{v}n"
    return f"{y}{v}z"


def nominal_question(word: str, person: str) -> str:
    v = four_way(last_vowel(word))
    suffix = {P1S: f"m{v}y{v}m", P2S: f"m{v}s{v}n", P1P: f"m{v}y{v}z"}.get(person, f"m{v}")
    return f"{word} {suffix}"


# ---------- fiil çekimi ----------

def conjugate(root: str, tense: str, person: str, neg: bool, question: bool) -> str:
    lv = last_vowel(root)
    is_back = lv in BACK
    v4 = four_way(lv)

    if tense == IMPERATIVE and not question:
        if person == P1P:
            soft = soften_verb_root(root)
            if neg:
                return root + ("mayalım" if is_back else "meyelim")
            return soft + ("alım" if is_back else "elim")
        return root + (("ma" if is_back else "me") if neg else "")

    if tense in (PRESENT, AORIST):
        stem = root + "m" if neg else (root[:-1] if root[-1] in "ae" else soften_verb_root(root))
        iyor_v = v4 if neg else four_way(last_vowel(stem, lv))
        core = f"{stem}{iyor_v}yor" if stem[-1] not in VOWELS else f"{stem}yor"
        if question:
            q = {P1S: "muyum", P2S: "musun", P1P: "muyuz"}.get(person, "mu")
            return f"{core} {q}"
        p = {P1S: "um", P2S: "sun", P3S: "", P1P: "uz", P2P: "sunuz", P3P: "lar"}[person]
        return core + p

    if tense == PAST_CONT:
        stem = root + "m" if neg else (root[:-1] if root[-1] in "ae" else soften_verb_root(root))
        iyor_v = v4 if neg else four_way(last_vowel(stem, lv))
        core = f"{stem}{iyor_v}yor" if stem[-1] not in VOWELS else f"{stem}yor"
        if question:
            return core + " mu" + {P1S: "ydum", P2S: "ydun", P1P: "yduk"}.get(person, "ydu")
        return core + {P1S: "dum", P2S: "dun", P1P: "duk", P3P: "lardı"}.get(person, "du")

    if tense == PAST:
        stem = root + (("ma" if is_back else "me") if neg else "")
        sv = ("ı" if is_back else "i") if neg else v4
        d_or_t = "t" if stem[-1] in HARD else "d"
        p = {P1S: "m", P2S: "n", P1P: "k", P3P: "lar" if is_back else "ler"}.get(person, "")
        conj = f"{stem}{d_or_t}{sv}{p}"
        return f"{conj} m{sv}" if question else conj

    if tense == FUTURE:
        stem = root + ("ma" if is_back else "me") if neg else soften_verb_root(root)
        buf = "y" if stem[-1] in VOWELS else ""
        acak = "acak" if is_back else "ecek"
        if question:
            return f"{stem}{buf}{acak} m{'ı' if is_back else 'i'}"
        if person == P1S:
            return f"{stem}{buf}{acak[:-1]}{'ğım' if is_back else 'ğim'}"
        if person == P2S:
            return f"{stem}{buf}{acak}{'sın' if is_back else 'sin'}"
        if person == P1P:
            return f"{stem}{buf}{acak[:-1]}{'ğız' if is_back else 'ğiz'}"
        return f"{stem}{buf}{acak}"

    if tense == CAN:
        soft = soften_verb_root(root)
        buf = "y" if soft[-1] in VOWELS else ""
        a_e = "a" if is_back else "e"
        i_i = "ı" if is_back else "i"
        if neg:
            base = f"{soft}{buf}{a_e}m{a_e}"
            return base + {P1S: "m", P2S: f"zs{i_i}n", P1P: f"y{i_i}z"}.get(person, "z")
        base = f"{soft}{buf}{a_e}bilir"
        if question:
            return base + " " + {P1S: "miyim", P2S: "misin", P1P: "miyiz"}.get(person, "mi")
        return base + {P1S: "im", P2S: "sin", P1P: "iz"}.get(person, "")

    if tense == MUST:
        neg_part = (("ma" if is_back else "me") if neg else "")
        mali = "malı" if is_back else "meli"
        p = {P1S: "yım" if is_back else "yim", P2S: "sın" if is_back else "sin",
             P1P: "yız" if is_back else "yiz"}.get(person, "")
        return root + neg_part + mali + p
    return root


# ---------- çözümleme ----------

def resolve_noun(token: str, proper: Set[str]) -> Optional[str]:
    if token.startswith("[") and token.endswith("]"):
        return token[1:-1].replace("=", " ")
    if token in NOUN_ADJ:
        return NOUN_ADJ[token]
    if token in QUESTION_WORDS:
        return QUESTION_WORDS[token]
    if token.endswith("ies") and len(token) > 4:
        root = NOUN_ADJ.get(token[:-3] + "y")
        if root:
            return root + ("lar" if any(c in "aıou" for c in root) else "ler")
    if token.endswith("s") and len(token) > 3:
        root = NOUN_ADJ.get(token[:-1])
        if root:
            return root + ("lar" if any(c in "aıou" for c in root) else "ler")
    if token in proper or token.isdigit():
        return capitalize_turkish(token)
    return None


def resolve_preposition(prep: str, target: str, proper: Set[str]) -> Optional[str]:
    if target in ("me", "you", "him", "her", "us", "them"):
        if prep == "with":
            return {"me": "benimle", "you": "seninle", "us": "bizimle"}.get(target, "onunla")
        if prep == "for":
            return {"me": "benim için", "you": "senin için", "us": "bizim için"}.get(target, "onun için")
        if prep == "to":
            return object_pronoun(target, DAT)
        if prep == "from":
            return object_pronoun(target, ABL)
        return None
    tr = resolve_noun(target, proper)
    if tr is None:
        return None
    if tr in ("burada", "orada"):
        if prep == "from":
            return tr[:-2] + "dan"   # buradan / oradan
        if prep == "to":
            return tr[:-2] + "ya"    # buraya / oraya
        return None
    if tr in ("bu", "şu"):
        gen = tr + "nun"
        return {"for": f"{gen} için", "about": f"{gen} hakkında", "with": f"{tr}nunla",
                "from": apply_case(tr, ABL, False), "to": apply_case(tr, DAT, False),
                "in": f"{tr}nda", "on": f"{tr}nda"}.get(prep)
    is_back = last_vowel(tr) in BACK
    d_or_t = "t" if tr[-1] in HARD else "d"
    a_e = "a" if is_back else "e"
    if prep in ("in", "on"):
        return f"{tr}{d_or_t}{a_e}"
    if prep == "from":
        return apply_case(tr, ABL, False)
    if prep == "to":
        return apply_case(tr, DAT, False)
    return {"with": f"{tr} ile", "without": f"{tr} olmadan", "for": f"{tr} için", "under": f"{tr} altında",
            "behind": f"{tr} arkasında", "about": f"{tr} hakkında"}.get(prep, tr)


def verb_entry(key: str) -> Optional[Tuple[str, str]]:
    return VERBS.get(key)


def detect_verb(token: str, tense: str) -> Optional[Tuple[Tuple[str, str], str]]:
    key = IRREGULAR_PAST.get(token)
    if key and key in VERBS:
        return VERBS[key], PAST
    if token in VERBS:
        return VERBS[token], tense
    if token.endswith("ing") and len(token) > 4:
        base = token[:-3]
        cands = [base, base + "e", base[:-1] if len(base) > 2 and base[-1] == base[-2] else ""]
        for c in cands:
            if c in VERBS:
                return VERBS[c], PRESENT
    if token.endswith("ed") and len(token) > 3:
        base = token[:-2]
        cands = [base, token[:-1], base[:-1] + "y" if base.endswith("i") else ""]
        for c in cands:
            if c in VERBS:
                return VERBS[c], PAST
    if token.endswith("s") and len(token) > 3:
        for c in (token[:-1], token[:-2]):
            if c in VERBS:
                return VERBS[c], PRESENT
    return None


# ---------- cümle ----------

def translate_sentence(sentence: str) -> Optional[str]:
    is_question_text = sentence.strip().endswith("?")
    end_punct = sentence[-1] if sentence and sentence[-1] in ".!?" else ""

    raw_words = re.split(r"\s+", re.sub(r"[^A-Za-z0-9\s]", " ", sentence).strip())
    proper = {w.lower() for w in raw_words[1:] if w and w[0].isupper()}

    normalized = expand_contractions(sentence.lower())
    normalized = re.sub(r"[^a-z0-9\s]", " ", normalized)
    normalized = re.sub(r"\s+", " ", normalized).strip()
    if not normalized:
        return sentence

    if normalized in PHRASES:
        return capitalize_turkish(PHRASES[normalized]) + end_punct

    for pat, rep in _PHRASAL:
        normalized = pat.sub(rep, normalized)
    for pat, rep in _PHRASE:
        normalized = pat.sub(rep, normalized)

    tokens: List[str] = [t for t in normalized.split(" ") if t.strip()]
    if not tokens:
        return None
    phrase_used = any(t.startswith("[") for t in tokens)

    person, has_subject, tense = P2S, False, IMPERATIVE
    negative, question = False, is_question_text
    q_tr: Optional[str] = None
    q_en: Optional[str] = None
    aux_seen = past_aux = dative_given = False
    adverbs: List[str] = []

    if tokens[0] in QUESTION_WORDS:
        q_en = tokens.pop(0)
        q_tr = QUESTION_WORDS[q_en]
        question = True

    if len(tokens) > 1 and tokens[0] in ("do", "does") and tokens[1] == "not" and not is_question_text:
        tokens.pop(0)  # "Do not go there." -> soru değil, olumsuz emir
    elif tokens and tokens[0] in AUX_START:
        question = True
        aux_seen = True
        aux = tokens.pop(0)
        if aux == "did":
            tense = PAST
        elif aux in ("was", "were"):
            tense, past_aux = PAST, True
        elif aux == "will":
            tense = FUTURE
        elif aux == "can":
            tense = CAN
        elif aux in ("am", "is", "are"):
            tense = PRESENT
        elif aux in ("do", "does"):
            tense = AORIST

    verb: Optional[Tuple[str, str]] = None
    subject: List[str] = []
    objects: List[str] = []

    i = 0
    while i < len(tokens):
        token = tokens[i]
        nxt = tokens[i + 1] if i + 1 < len(tokens) else None

        if token in ("the", "a", "an", "please"):
            if token == "please":
                subject.append("lütfen")
            i += 1
            continue

        if token in ("not", "never"):
            negative = True
            if token == "never":
                subject.append("asla")
            i += 1
            continue
        if token == "will":
            tense = FUTURE; i += 1; continue
        if token == "can":
            tense = CAN; i += 1; continue
        if token in ("must", "should"):
            tense = MUST; i += 1; continue
        if token in ("am", "is", "are"):
            tense = PRESENT; i += 1; continue
        if token in ("was", "were"):
            tense, past_aux = PAST, True; i += 1; continue
        if token == "had":
            tense = PAST; i += 1; continue
        if token in ("did", "do", "does") and not aux_seen and nxt == "not":
            tense = PAST if token == "did" else AORIST
            i += 1
            continue
        if token == "let" and nxt == "us":
            person, has_subject = P1P, True
            subject.append("hadi")
            i += 2
            continue

        if verb is None:
            detected = None if token in ADJ_PARTICIPLES else detect_verb(token, tense)
            if detected is not None:
                verb = detected[0]
                tense = PAST_CONT if past_aux and detected[1] == PRESENT else detected[1]
                i += 1
                continue
            pron = {"i": P1S, "you": P2S, "he": P3S, "she": P3S, "it": P3S, "we": P1P, "they": P3P}.get(token)
            if pron:
                person, has_subject = pron, True
                i += 1
                continue

        if token in POSSESSIVES and nxt is not None:
            noun = resolve_noun(nxt, proper)
            if noun is None or nxt.startswith("["):
                return None
            owned = possessive(noun, token)
            if verb is None:
                person, has_subject = P3S, True
                subject.append(owned)
            else:
                case = ACC if dative_given and verb[1] == DAT else verb[1]
                objects.append(apply_case(owned, case, True))
            i += 2
            continue

        if token in PREPOSITIONS:
            idx = i + 2 if nxt in ("the", "a", "an") else i + 1
            if idx < len(tokens):
                combined = resolve_preposition(token, tokens[idx], proper)
                if combined is None:
                    return None
                objects.append(combined)
                i = idx + 1
                continue

        if verb is not None and token in OBJ_PRONOUNS:
            indirect = verb[0] in DITRANSITIVE and not dative_given and nxt is not None
            case = DAT if indirect else verb[1]
            if case == NONE:
                return None  # fiil hangi hali istediğini bilmiyoruz: model çevirsin
            if indirect:
                dative_given = True
            if nxt == "all" and token in ("them", "us"):
                objects.append(all_pronoun(token, case))
                i += 2
                continue
            objects.append(object_pronoun(token, case))
            i += 1
            continue

        resolved = resolve_noun(token, proper)
        if resolved is None:
            return None
        if token in TIME_ADVERBS:
            adverbs.append(resolved)
        elif verb is None:
            if not has_subject:
                has_subject, person = True, P3S
            subject.append(resolved)
        else:
            if token in ("here", "there") and verb[1] == DAT:
                resolved = "buraya" if token == "here" else "oraya"
            last = i == len(tokens) - 1
            case = ACC if dative_given and verb[1] == DAT else verb[1]
            objects.append(apply_case(resolved, case, False) if last else resolved)
        i += 1

    out: List[str] = adverbs + subject + objects
    if q_tr is not None:
        where_to_go = q_en == "where" and verb is not None and verb[1] == DAT
        out.append("nereye" if where_to_go else q_tr)

    if verb is not None:
        if tense == IMPERATIVE and has_subject:
            tense = PRESENT
        out.append(conjugate(verb[0], tense, person, negative, question and q_tr is None))
    elif negative:
        if phrase_used:
            return None  # "Don't leave me alone": olumsuz emir + hazır kalıp, kural motoru emin değil
        out.append("değil mi" if question and q_tr is None else "değil" + copula_suffix("değil", person))
    elif question and q_tr is None and not phrase_used and out:
        out.append(nominal_question(out.pop(), person))
    elif (not question and q_tr is None and has_subject and subject and tense == PRESENT
          and person in (P1S, P2S, P1P)):
        last_word = out.pop()
        out.append(last_word + copula_suffix(last_word, person))

    if verb is None and q_tr is not None and out == [q_tr]:
        # "Who are you?" -> "Sen kimsin?"; öbür soru kelimeleri + zamir: emin değiliz
        if q_en == "who" and has_subject and person in (P1S, P2S, P1P):
            out = ["sen" if person == P2S else "ben" if person == P1S else "biz", "kim" + copula_suffix("kim", person)]
        elif has_subject:
            return None

    text = re.sub(r"\s+", " ", " ".join(out)).strip()
    if not text:
        return None
    return capitalize_turkish(text) + end_punct


class FastTranslator:
    """translate_or_none(): emin olduğu cümleyi çevirir, emin değilse None döner."""

    def __init__(self, cache_size: int = 1000):
        self._cache: "OrderedDict[str, str]" = OrderedDict()
        self._size = cache_size
        self._lock = threading.Lock()

    def translate_or_none(self, raw: str) -> Optional[str]:
        cleaned = clean_ocr_noise(raw)
        if not cleaned:
            return None
        with self._lock:
            hit = self._cache.get(cleaned)
            if hit is not None:
                self._cache.move_to_end(cleaned)
                return hit

        m = _SPEAKER.match(cleaned)
        prefix, body = (m.group(1) + " ", m.group(2)) if m else ("", cleaned)
        parts: List[str] = []
        for s in _SENTENCE_SPLIT.split(body):
            t = translate_sentence(s)
            if t is None:
                return None
            parts.append(t)
        result = prefix + " ".join(parts)
        with self._lock:
            self._cache[cleaned] = result
            if len(self._cache) > self._size:
                self._cache.popitem(last=False)
        return result
