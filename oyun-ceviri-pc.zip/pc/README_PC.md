# Oyun Çeviri – Bilgisayar sürümü

Bilgisayarda Xbox uygulamasından uzaktan oynarken ekranın altındaki İngilizce altyazıyı okur,
Türkçeye çevirir ve TV'deki **Oyun Çeviri TV** uygulamasına gönderir. Telefon gerekmez.
**TV uygulaması aynıdır**, telefon sürümüyle birlikte kurduğun uygulama bununla da çalışır.

## Kurulum (bir kere)
1. **Python 3.12** kur: https://www.python.org/downloads/ (kurarken **"Add python.exe to PATH"** kutusunu işaretle;
   "tcl/tk" seçeneği açık kalsın, arayüz için gerekir).
2. Bu `pc` klasöründe `kur.bat`'a çift tıkla (paketleri indirir).
3. İsteğe bağlı, internetsiz yedek çeviri: komut satırında `python -m pip install argostranslate`.

## Kullanım
1. TV'de **Oyun Çeviri TV** → *Servisi başlat*. Ekranda 8 haneli kod görünür.
2. Bilgisayarda Xbox uygulamasında oyunu aç.
3. `baslat.bat`'a çift tıkla, pencere açılır:
   - **TV kodu**: TV'de görünen kod. TV'yi otomatik bulamazsa **TV IP adresini** de yaz (router'dan ya da TV ağ ayarlarından).
   - **Gemini anahtarı** (https://aistudio.google.com/apikey): doğal çeviri için önerilir.
   - **Oyun adı** ve **Özel sözlük** (`Ripperdoc=Siberdoktor, Night City=Night City`): isimler doğru çıksın.
   - **Ekrandan alan seç**: altyazının çıktığı bölgeyi fareyle sürükle. (Ana monitörde çalışır.)
4. **ÇEVİRİYİ BAŞLAT**. Pencerede EN/TR satırları akar, TV'de çeviri görünür.
5. *TV'ye test altyazısı* düğmesiyle oyun olmadan bağlantıyı deneyebilirsin.

## Önce ekran testi (önemli)
Windows bazı pencereleri yakalayamayıp siyah verebilir. Oyun açıkken konsolda:
`baslat_konsol.bat --onizleme` → `onizleme.png` dosyasını aç. **Altyazı görünüyorsa** tamam, siyahsa bu yöntem çalışmaz.

## Çeviri sırası
1. **Gemini** (anahtar varsa). İyi çeviriler `ceviri_hafizasi.db`'ye yazılır; aynı satır tekrar gelince anında çıkar.
   Zayıf/yedek çeviriler hafızaya **yazılmaz**.
2. **Ollama** (isteğe bağlı): bilgisayarda yerel yapay zekâ. https://ollama.com kur, `ollama pull gemma2:2b`, pencerede model adını yaz.
3. **Argos** (kuruluysa): internetsiz yedek.

## Konsol kullanımı (arayüzsüz)
`baslat_konsol.bat` ya da `python oyunceviri_pc.py` (ilk seferde soru sorar). Seçenekler: `--test-tv`, `--onizleme`,
`--monitorler`, `--resim ekran.png`, `--tv-ip`, `--ust 65`, `--bolge x,y,g,y`, `--kurulum`.

## Notlar
- Gemini anahtarı `ayarlar.json` içinde düz metin saklanır (kişisel kullanım). Başkasına verirken sil.
- Xbox penceresi küçültülmemeli. Altyazı değişmeyen karelerde OCR atlanır, işlemciyi yormaz.
- TV bağlantısı kodla korunur; kod yanlışsa "unauthorized" görürsün ve yeniden denenmez.
- **Bu sürüm Windows'ta denenmedi.** Test edilenler: altyazı mantığı, çeviri sırası/hafıza/sözlük, TV protokolü
  (sahte TV sunucusuyla) ve sahte ekranla uçtan uca akış (`python -m unittest discover -s . -t .`, 56 test).
  Denenmeyenler: gerçek ekran yakalama, rapidocr OCR, mDNS ile TV bulma ve tkinter arayüzü (ilk kez senin bilgisayarında çalışacak).

## Yazı boyutu / rengi ve oyunun kendi altyazısını kapatma

GUI'deki "TV yazı görünümü" bölümünde boyut, arka plan koyuluğu, renk, yükseklik ve kapatma kutusu ayarları var; çeviri çalışırken değiştirince TV'de anında uygulanır.

Oyunun kendi altyazısı görüntünün içinde olduğu için silinemez; onun yerine üstüne opak bir kutu koyarız:
1. "Oyunun kendi altyazısını kapat" düğmesine bas (arka plan %100, kutu açılır).
2. "TV'ye test altyazısı" ile bak. Kutu orijinal altyazıyı tam örtmüyorsa "Alttan yükseklik", "Kapatma kutusu yüksekliği" ve "genişliği" çubuklarını ayarla.
3. Kapatmak istemezsen "Kapatma kutusu yüksekliği" = 0.

Not: renk, yükseklik ve kutu için TV uygulamasının yeni sürümü (APK) gerekir; boyut ve arka plan eski TV uygulamasıyla da çalışır.
Çeviri başlayınca pencere küçülür, böylece seçili alan GUI'nin kendi yazısını okumaz.

## Gecikmeyi azaltma ve çevrimdışı mod

Bu sürümdeki hız iyileştirmeleri:
- **Kalıcı Gemini bağlantısı:** Her satırda yeni TLS bağlantısı kurulmaz (satır başına yaklaşık 200-400 ms kazanç).
- **Akıllı OCR:** Karede açık renkli yazı yoksa OCR hiç çalışmaz; varsa yalnızca yazının bulunduğu kutu okunur.
- **Daha sık kare:** Kare aralığı 250 ms'den 120 ms'ye indi. Altyazı 2 kare art arda görülünce çevrilir, silme gecikmesi 400 ms.
- **Önbellek:** Daha önce çevrilen satır Gemini'ye gitmeden anında gelir.
- **Gecikme ölçümü:** Günlükte `⏱ taslak: 90 ms` ve `⏱ çeviri: 640 ms` yazar (altyazı görülünce TV'ye gidene kadar geçen süre).

**Çeviri modu** (pencerede "Çeviri modu", ya da `--mod`):
- `online`: Gemini; internet ya da Gemini giderse çevrimdışı yedek.
- `hybrid`: Önce anında çevrimdışı taslak gösterilir, Gemini çevirisi gelince onun yerine geçer. Hızlı diyaloglarda en az gecikmeli seçenek budur, yalnızca taslak biraz kaba olabilir.
- `offline`: İnternet gerekmez, Gemini kullanılmaz.

Çevrimdışı için bir kere `cevrimdisi_hazirla.bat` çalıştır (internetle model indirir, yaklaşık 100 MB). Hazır oyun cümleleri ("Finish him", "Get over here" gibi) model çalışmadan anında çevrilir; kendi terimlerini "Özel sözlük" ile ekleyebilirsin.

Ayarları elle değiştirmek istersen `ayarlar.json` içinde `frame_ms` (kare aralığı, varsayılan 120), `stable_frames` (2) ve `clear_ms` (400) var. Çok sık yanlış okuma görürsen `stable_frames`'i 3 yap.

## Hızlı yerel çeviri (kural motoru)

Pencerede "Hızlı yerel çeviri" kutusu açıkken kısa ve basit cümleler (ör. "Open the door.", "I will find the key.", "Don't shoot!") internetsiz ve gecikmesiz, Türkçe dilbilgisi kurallarıyla çevrilir. Emin olmadığı cümleyi (bilmediği kelime, karmaşık yapı) çevirmez; o cümle Gemini'ye, o da olmazsa çevrimdışı modele gider. Böylece ekranda yarı İngilizce bozuk bir cümle çıkmaz.

- Hibrit modda taslak olarak da kullanılır: bu motorun bildiği cümle anında gelir, Gemini'ye gitmez.
- "Özel sözlük"te yazdığın bir terim cümlede geçiyorsa cümle bu motora değil Gemini'ye gider (terimin doğru çıkması için).
- Gemini kadar doğal değildir ("Hello there" gibi deyimlerde kelime kelime çevirebilir). Beğenmezsen kutuyu kapat; ayar kaydedilir.
- Sözlük ve kurallar `fast_local.py` ve `fast_local_data.py` içindedir. Yeni kelime/kalıp eklemek için `fast_local_data.py` dosyasındaki `PHRASES`, `NOUN_ADJ` ve `VERBS` listelerine satır eklemen yeterli.

## Hy-MT ile yüksek kaliteli çevrimdışı çeviri (Ollama)

Tencent'in HY-MT1.5-1.8B çeviri modeli Türkçe'yi destekler ve küçüktür. Ollama ile bilgisayarında çalıştırıp "Ollama modeli" kutusuna model adını yazarsan çevrimdışı zincirde Argos'tan önce o denenir. Model adında `hy-mt` geçiyorsa uygulama modelin kendi sade çeviri istemini kullanır.

1. https://ollama.com adresinden Ollama'yı kur.
2. Komut satırında modeli indir. Örnek: `ollama pull hf.co/tencent/HY-MT1.5-1.8B-GGUF` (depo adı değişmiş olabilir; Hugging Face'te "HY-MT1.5-1.8B GGUF" ara).
3. Uygulamada "Ollama modeli" kutusuna indirdiğin tam adı yaz (ör. `hf.co/tencent/HY-MT1.5-1.8B-GGUF`).

## Çeviri kalitesi (önemli)

- En iyi sonuç **Gemini anahtarı** girilince gelir. Anahtar varken kural motoru ve çevrimdışı taslak
  devreye girmez (kötü çeviri üretiyorlardı); çevrimdışı motorlar yalnızca anahtar yoksa, internet
  kesilirse veya mod "offline" ise kullanılır.
- Mod "online" kalsın ("hybrid" önce kaba taslak gösterir).
- Hâlâ zayıfsa Gemini model adını daha büyük bir modele (ör. `gemini-3.8-flash`, daha kaliteli ama biraz yavaş; hızlı kalmak için `gemini-3.5-flash-lite`) çevir; adları
  https://ai.google.dev/gemini-api/docs/models sayfasından kontrol et.
- "Sözlük" kutusuna `Jax=Jax` ya da `Kronika=Kronika` gibi satırlar ekleyerek isimleri sabitleyebilirsin.
