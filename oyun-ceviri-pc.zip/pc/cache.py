"""Kalıcı çeviri hafızası (sqlite). Yalnızca İYİ çeviriler (Gemini/Ollama) kaydedilir."""
from __future__ import annotations

import os
import sqlite3
import threading
from contextlib import closing
from typing import Optional

from subtitle_core import key as text_key

DEFAULT_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ceviri_hafizasi.db")


class PersistentCache:
    def __init__(self, path: str = DEFAULT_PATH):
        self._path = path
        self._lock = threading.Lock()
        self._run("CREATE TABLE IF NOT EXISTS cache (k TEXT PRIMARY KEY, tr TEXT)")

    def _run(self, sql: str, params=(), fetch: bool = False):
        """Her işlemde bağlantıyı kapatır (Windows'ta dosya kilidi kalmasın)."""
        with self._lock, closing(sqlite3.connect(self._path, timeout=5)) as conn:
            with conn:  # commit/rollback
                cur = conn.execute(sql, params)
                return cur.fetchone() if fetch else None

    @staticmethod
    def make_key(namespace: str, text: str) -> str:
        # Harf/rakam anahtarı: OCR'ın noktalama/boşluk titremesi aynı kayda düşer
        return f"{namespace}|{text_key(text)}"

    def get(self, namespace: str, text: str) -> Optional[str]:
        try:
            row = self._run("SELECT tr FROM cache WHERE k = ?", (self.make_key(namespace, text),), fetch=True)
            return row[0] if row else None
        except sqlite3.Error:
            return None

    def put(self, namespace: str, text: str, translation: str) -> None:
        try:
            self._run("INSERT OR REPLACE INTO cache (k, tr) VALUES (?, ?)",
                      (self.make_key(namespace, text), translation))
        except sqlite3.Error:
            pass

    def clear(self) -> None:
        try:
            self._run("DELETE FROM cache")
        except sqlite3.Error:
            pass
