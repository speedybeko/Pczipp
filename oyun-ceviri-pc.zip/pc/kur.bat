@echo off
chcp 65001 >nul
echo Gerekli paketler kuruluyor...
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
echo.
echo Cevrimdisi yedek ceviri istersen su komutu da calistir:  python -m pip install argostranslate
echo Kurulum bitti. Baslatmak icin baslat.bat dosyasina cift tikla.
pause
