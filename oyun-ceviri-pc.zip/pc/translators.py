"""Çeviri motorları: Gemini (internet) ve Argos (çevrimdışı, isteğe bağlı)."""
from __future__ import annotations

import http.client
import json
import socket
import threading
import urllib.error
import urllib.request
from collections import OrderedDict, deque
from typing import Deque, Dict, Optional, Tuple
from urllib.parse import quote, urlencode

from subtitle_core import TranslationError

SYSTEM = (
    "You are a professional game localizer translating English subtitles into natural Turkish "
    "(the quality of an official Turkish game localization, not literal machine translation). "
    "Rules:\n"
    "1. Translate the MEANING of the whole sentence; use idiomatic, spoken Turkish with correct "
    "suffixes and word order. Never translate word by word.\n"
    "2. Translate EVERY ordinary English word ('united', 'ally', 'route', 'worry'). Only character "
    "names, place names, realm names and invented proper nouns stay unchanged.\n"
    "3. Keep the speaker's tone (threats, sarcasm, formality). Use informal 'sen' between friends "
    "and rivals, 'siz' only for respect or plural.\n"
    "4. The text comes from OCR and may have small errors (I/l, 0/O, missing letters, merged words); "
    "silently fix them using context.\n"
    "5. Previous lines are context only: never translate, repeat or merge them. If the subtitle is "
    "the continuation of the previous line, translate it so that it reads well after it.\n"
    "6. Output ONLY the Turkish translation of the given subtitle: no quotes, notes, labels or alternatives. "
    "Keep it as short as natural Turkish allows.\n"
    "Examples:\n"
    "EN: We are unlikely allies, united for a common cause. Worry not.\n"
    "TR: Olası olmayan müttefikleriz ama ortak bir dava için birleştik. Merak etmeyin.\n"
    "EN: I'm not usually surrounded by so many friendly faces.\n"
    "TR: Etrafımda bu kadar çok dost yüz görmeye pek alışık değilim.\n"
    "EN: They're en route. Kitana and I will see that they arrive as planned.\n"
    "TR: Yoldalar. Kitana'yla ben, planlandığı gibi varmalarını sağlayacağız.\n"
    "EN: Thank you, both of you.\n"
    "TR: İkinize de teşekkürler.\n"
)


class KeepAlivePool:
    """Thread başına kalıcı HTTPS bağlantısı. Her çeviride yeni TLS el sıkışması (~200-400 ms) yapmaz."""

    def __init__(self, host: str, timeout: float, factory=http.client.HTTPSConnection):
        self._host, self._timeout, self._factory = host, timeout, factory
        self._local = threading.local()

    def _conn(self) -> http.client.HTTPSConnection:
        c = getattr(self._local, "conn", None)
        if c is None:
            c = self._factory(self._host, timeout=self._timeout)
            self._local.conn = c
        return c

    def _drop(self) -> None:
        c = getattr(self._local, "conn", None)
        self._local.conn = None
        if c is not None:
            try:
                c.close()
            except OSError:
                pass

    def post(self, path: str, body: bytes, headers: Dict[str, str]) -> Tuple[int, str]:
        """(durum kodu, gövde). Bağlantı kopmuşsa bir kez yeniden bağlanıp dener; ağ hatasında OSError fırlatır."""
        last: Optional[Exception] = None
        for _ in range(2):
            try:
                c = self._conn()
                c.request("POST", path, body=body, headers=headers)
                r = c.getresponse()
                data = r.read().decode("utf-8", "replace")
                if r.will_close:
                    self._drop()
                return r.status, data
            except (http.client.HTTPException, OSError) as e:  # kopan keep-alive, zaman aşımı...
                last = e
                self._drop()
        raise OSError(str(last))


class GeminiTranslator:
    """Önceki 3 satırı bağlam olarak gönderir, aynı metni önbellekten verir."""

    def __init__(self, api_key: str, model: str, game_hint: str = "", timeout: float = 7.0,
                 glossary_hint: str = ""):
        self._glossary_hint = glossary_hint
        self._key = api_key
        self._model = model
        self._game = game_hint
        self._timeout = timeout
        self._lock = threading.Lock()
        self._history: Deque[str] = deque(maxlen=3)
        self._cache: Dict[str, str] = {}
        self._pool = KeepAlivePool("generativelanguage.googleapis.com", timeout)

    def _post(self, path: str, body: bytes) -> Tuple[int, str]:
        return self._pool.post(path, body, {"Content-Type": "application/json; charset=utf-8"})

    def translate(self, text: str) -> str:
        with self._lock:
            cached = self._cache.get(text)
        if cached is not None:
            return cached

        path = (
            f"/v1beta/models/{quote(self._model, safe='')}:generateContent?" + urlencode({"key": self._key})
        )
        body = json.dumps(self._build_body(text)).encode("utf-8")
        try:
            status, payload = self._post(path, body)
        except OSError as e:
            raise TranslationError(0, "Ağ hatası") from e
        if status >= 400:
            raise TranslationError(status, f"HTTP {status}")

        out = self.parse(payload)
        if out is None:
            raise TranslationError(0, "Boş yanıt (güvenlik filtresi olabilir)")
        with self._lock:
            if len(self._cache) > 200:
                self._cache.clear()
            self._cache[text] = out
            self._history.append(text)
        return out

    def _build_body(self, text: str) -> dict:
        with self._lock:
            prev = list(self._history)
        parts = []
        if self._game:
            parts.append(f"Game: {self._game}\n")
        if self._glossary_hint:
            parts.append(self._glossary_hint + "\n")
        if prev:
            parts.append("Previous subtitle lines (context only, do not translate them):")
            parts.extend(f"- {p}" for p in prev)
            parts.append("")
        parts.append("Translate this subtitle into Turkish:")
        parts.append(text)
        return {
            "systemInstruction": {"parts": [{"text": SYSTEM}]},
            "contents": [{"role": "user", "parts": [{"text": "\n".join(parts)}]}],
            "generationConfig": {"temperature": 0.2},
        }

    @staticmethod
    def parse(payload: str):
        try:
            parts = json.loads(payload)["candidates"][0]["content"]["parts"]
            text = "".join(p.get("text", "") for p in parts).strip()
        except (KeyError, IndexError, TypeError, ValueError):
            return None
        if len(text) >= 2 and text[0] == '"' and text[-1] == '"':
            text = text[1:-1].strip()
        return text or None

    def close(self) -> None:
        pass


class ArgosTranslator:
    """Çevrimdışı İngilizce -> Türkçe (pip install argostranslate). Model ilk kullanımda iner."""

    def __init__(self, on_notice=lambda _m: None):
        self._notice = on_notice
        self._ready = False
        self._lock = threading.Lock()          # model yükleme
        self._run_lock = threading.Lock()      # ctranslate2'yi aynı anda tek thread kullansın
        self._memo: "OrderedDict[str, str]" = OrderedDict()  # aynı satır tekrarlanırsa model çalışmaz

    def warm_up(self) -> None:
        """Modeli önceden yükler; ilk gerçek altyazıda yükleme gecikmesi olmaz."""
        self._ensure()
        self.translate("Hello.")

    def _ensure(self) -> None:
        if self._ready:
            return
        with self._lock:
            if self._ready:
                return
            try:
                import argostranslate.package as package
                import argostranslate.translate as translate
            except ImportError as e:
                raise TranslationError(0, "argostranslate kurulu değil (pip install argostranslate)") from e
            try:
                langs = {l.code: l for l in translate.get_installed_languages()}
                en, tr = langs.get("en"), langs.get("tr")
                if not (en and tr and en.get_translation(tr)):
                    self._notice("Çevrimdışı çeviri modeli indiriliyor (bir kereye mahsus)...")
                    package.update_package_index()
                    pkg = next(
                        p for p in package.get_available_packages() if p.from_code == "en" and p.to_code == "tr"
                    )
                    package.install_from_path(pkg.download())
                self._ready = True
            except Exception as e:  # noqa: BLE001 - ağ/disk hataları çeşitli
                raise TranslationError(0, f"Çevrimdışı model hazırlanamadı: {e}") from e

    def translate(self, text: str) -> str:
        with self._run_lock:
            hit = self._memo.get(text)
            if hit is not None:
                self._memo.move_to_end(text)
                return hit
        self._ensure()
        import argostranslate.translate as translate

        try:
            with self._run_lock:
                out = translate.translate(text, "en", "tr")
        except Exception as e:  # noqa: BLE001
            raise TranslationError(0, f"Çeviri başarısız: {e}") from e
        with self._run_lock:
            self._memo[text] = out
            if len(self._memo) > 300:
                self._memo.popitem(last=False)
        return out

    def close(self) -> None:
        pass


class OllamaTranslator:
    """Bilgisayardaki yerel yapay zekâ (https://ollama.com). Ekran kartı varsa hızlı ve ücretsizdir."""

    def __init__(self, model: str, game_hint: str = "", glossary_hint: str = "",
                 url: str = "http://127.0.0.1:11434/api/generate", timeout: float = 20.0):
        self._model, self._game, self._hint, self._url, self._timeout = model, game_hint, glossary_hint, url, timeout
        self._lock = threading.Lock()
        self._history: Deque[str] = deque(maxlen=3)

    @property
    def is_hymt(self) -> bool:
        """Tencent HY-MT çeviri modelleri sohbet değil sadece çeviri bilir; kendi sade istemini ister."""
        name = self._model.lower().replace("_", "-")
        return "hy-mt" in name or "hymt" in name

    def build_request(self, text: str) -> dict:
        if self.is_hymt:
            # Model kartındaki şablon ve önerilen örnekleme ayarları (açıklama/bağlam istemi karıştırılmaz)
            prompt = f"Translate the following segment into Turkish, without additional explanation.\n\n{text}"
            options = {"temperature": 0.3, "top_k": 20, "top_p": 0.6, "repeat_penalty": 1.05, "num_predict": 120}
            return {"model": self._model, "prompt": prompt, "stream": False, "options": options}
        with self._lock:
            prev = list(self._history)
        prompt = SYSTEM + "\n\n"
        if self._game:
            prompt += f"Game: {self._game}\n"
        if self._hint:
            prompt += self._hint + "\n"
        if prev:
            prompt += "Previous lines (context only):\n" + "\n".join(f"- {p}" for p in prev) + "\n"
        prompt += f"\nTranslate this subtitle into Turkish:\n{text}"
        return {"model": self._model, "prompt": prompt, "stream": False,
                "options": {"temperature": 0.2, "num_predict": 120}}

    def translate(self, text: str) -> str:
        body = json.dumps(self.build_request(text)).encode("utf-8")
        req = urllib.request.Request(self._url, data=body, headers={"Content-Type": "application/json"}, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=self._timeout) as resp:
                payload = resp.read().decode("utf-8", "replace")
        except urllib.error.HTTPError as e:
            raise TranslationError(e.code if e.code != 404 else 0, "Ollama hatası (model yüklü mü?)") from e
        except (urllib.error.URLError, socket.timeout, OSError) as e:
            raise TranslationError(0, "Ollama çalışmıyor") from e
        out = self.parse(payload)
        if out is None:
            raise TranslationError(0, "Ollama boş yanıt verdi")
        with self._lock:
            self._history.append(text)
        return out

    @staticmethod
    def parse(payload: str):
        try:
            text = str(json.loads(payload).get("response", "")).strip()
        except (ValueError, AttributeError):
            return None
        if len(text) >= 2 and text[0] == text[-1] and text[0] in "\"'":
            text = text[1:-1].strip()
        return text or None

    def close(self) -> None:
        pass


class CachingTranslator:
    """İyi motorun (Gemini/Ollama) çevirilerini kalıcı hafızaya yazar, tekrar gelen satırı anında verir."""

    def __init__(self, inner, cache, namespace: str):
        self._inner, self._cache, self._ns = inner, cache, namespace

    def translate(self, text: str) -> str:
        hit = self._cache.get(self._ns, text)
        if hit is not None:
            return hit
        out = self._inner.translate(text)
        self._cache.put(self._ns, text, out)
        return out

    def close(self) -> None:
        self._inner.close()


class ChainTranslator:
    """Sırayla dener; hepsi başarısızsa son hatayı fırlatır."""

    def __init__(self, translators):
        self._translators = [t for t in translators if t is not None]

    def translate(self, text: str) -> str:
        last: Exception = TranslationError(0, "Çeviri motoru yok")
        for t in self._translators:
            try:
                return t.translate(text)
            except TranslationError as e:
                last = e
        raise last

    def warm_up(self) -> None:
        for t in self._translators:
            warm = getattr(t, "warm_up", None)
            if warm is not None:
                warm()

    def close(self) -> None:
        for t in self._translators:
            t.close()


class PhrasebookTranslator:
    """Çevrimdışı hızlı yol: bilinen oyun cümleleri model çalıştırılmadan (≈0 ms) ve doğru çevrilir.

    Eşleşme büyük/küçük harf, noktalama ve boşluktan bağımsızdır; eşleşme yoksa `inner` çevirir.
    """

    def __init__(self, inner, phrases: Dict[str, str]):
        from subtitle_core import key  # noqa: PLC0415

        self._inner = inner
        self._key = key
        self._phrases = {key(k): v for k, v in phrases.items() if key(k)}

    def lookup(self, text: str) -> Optional[str]:
        return self._phrases.get(self._key(text))

    def translate(self, text: str) -> str:
        hit = self.lookup(text)
        if hit is not None:
            return hit
        return self._inner.translate(text)

    def warm_up(self) -> None:
        warm = getattr(self._inner, "warm_up", None)
        if warm is not None:
            warm()

    def close(self) -> None:
        self._inner.close()


class ReplacingTranslator:
    """Çevrimdışı motor için: özel sözlük terimlerini çeviriden önce yerine koyar."""

    def __init__(self, inner, mapping):
        self._inner, self._mapping = inner, mapping

    def translate(self, text: str) -> str:
        from glossary import apply_replacements

        return self._inner.translate(apply_replacements(text, self._mapping))

    def warm_up(self) -> None:
        warm = getattr(self._inner, "warm_up", None)
        if warm is not None:
            warm()

    def close(self) -> None:
        self._inner.close()
